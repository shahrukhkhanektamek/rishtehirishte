<!--  Start Header Area -->
<?php include"include/header.php"; ?>
<!-- End Header Area -->

    <div class="hom-top inner_style">

    <?php include"include/header-nav.php"; ?>

    <!-- BANNER -->
    <section>
        <div class="str">
            <div class="ban-inn ab-ban pg-cont" style="background: linear-gradient(to right, rgb(137, 33, 107), rgb(218, 68, 83));">
                <div class="container">
                    <div class="row">
                        <div class="hom-ban">
                            <div class="ban-tit">
                                <h1>Rishte Hi Rishte Matrimonial</h1>
                                <h4 class="fw-light text-white">Best Marriage Bureau in Delhi</h4>
                                <p>We're Your Extended Family. Service Towards Success.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

    <!-- START -->
    <section>
        <div class="ab-sec2">
            <div class="container">
                <div class="row">
                    <ul>
                        <li>
                            <div class="success-image-div">
                                <span>
                                    <img src="images/icon/prize.png" alt="">
                                    <h4>Genuine profiles</h4>
                                    <!-- <p>The most trusted wedding Matrimonial brand</p> -->
                                </span>
                            </div>
                        </li>
                        <li>
                            <div class="success-image-div">
                                <span>
                                    <img src="images/icon/trust.png" alt="">
                                    <h4>Most trusted</h4>
                                    <!-- <p>The most trusted wedding Matrimonial brand</p> -->
                                </span>
                            </div>
                        </li>
                        <li>
                            <div class="success-image-div">
                                <span>
                                    <img src="images/icon/rings.png" alt="">
                                    <h4>Personalized Matchmaking | 100% Privacy</h4>
                                    <!-- <p>The most trusted wedding Matrimonial brand</p> -->
                                </span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->


    <!-- ABOUT START -->
    <section class="pt-60 pb-60">
        <div class="ab-wel">
            <div class="container">
                <div class="row align-items-start">
                    <div class="col-lg-6 pe-md-5">
                        <div class="ab-wel-lhs">
                            <!-- <span class="ab-wel-3"></span> -->
                            <img src="https://diamondmatrimonialservices.com/images/abouthome.png" alt="image" loading="lazy" class="img-fluid w-100 ab-wel-1">
                            <!-- <img src="images/couples/20.jpg" alt="" loading="lazy" class="ab-wel-2">
                            <span class="ab-wel-4"></span> -->
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="ab-wel-rhs">
                            <div class="ab-wel-tit home-tit text-start">
                                <h2 class="mb-0" style="line-height: 0.9;font-size: 45px;">Rishte Hi Rishte Matrimonial
                                    <em class="m-0">Best Marriage Bureau in Delhi</em>
                                </h2>
                                <em class="mb-3 d-block">We're Your Extended Family. Service Towards Success.</em>
                                <span class="leaf1 mx-0"></span>
                            </div>
                            <div class="ab-wel-tit-1 mb-0">
                                <p class="mb-3">
                                     <?=$about->sort?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mt-5">
                        <p><?=$about->full?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

<!--  Start Footer Area -->
<?php include"include/footer.php"; ?>
<!-- End Footer Area --> 