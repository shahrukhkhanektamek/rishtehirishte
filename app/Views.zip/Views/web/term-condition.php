<!--  Start Header Area -->
<?php include"include/header.php"; ?>
<!-- End Header Area -->

    <div class="hom-top inner_style">

    <?php include"include/header-nav.php"; ?>

    <!-- BANNER -->
    <section>
        <div class="str">
            <div class="ban-inn ab-ban pg-cont" style="background: linear-gradient(to right, rgb(137, 33, 107), rgb(218, 68, 83));">
                <div class="container">
                    <div class="row">
                        <div class="hom-ban">
                            <div class="ban-tit">
                                <h1>Terms & Condition</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

 


    <!-- ABOUT START -->
    <section class=" pb-60">
        <div class="ab-wel">
            <div class="container">
                <div class="row align-items-start">
                    
                    <div class="col-lg-12">
                        <div class="ab-wel-rhs">
                            <div class="ab-wel-tit home-tit text-center d-none">
                                <h2 class="mb-0" style="line-height: 0.9;font-size: 45px;">Terms & Condition</h2>
                            </div>
                            <div class="ab-wel-tit-1 mb-0 border-0">
                                <p class="mb-3">
                                    <?=$policy->terms_policy ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

<!--  Start Footer Area -->
<?php include"include/footer.php"; ?>
<!-- End Footer Area --> 