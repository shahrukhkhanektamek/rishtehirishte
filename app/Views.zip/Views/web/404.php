<!--  Start Header Area -->
<?php include"include/header.php"; ?>
<!-- End Header Area -->

    <div class="hom-top login_style">

    <?php include"include/header-nav.php"; ?>

    



    <!-- ABOUT START -->
    <section class="pt-80 pb-80">
        <div class="ab-wel">
            <div class="container">
                <div class="row align-items-start">
                    <div class="col-lg-12">
                        <div class="ab-wel-rhs">
                            <div class="ab-wel-tit home-tit text-start">
                                <h2 class="mb-0" style="line-height: 0.9;font-size: 100px;text-align: center;">404</h2>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

<!--  Start Footer Area -->
<?php include"include/footer.php"; ?>
<!-- End Footer Area --> 