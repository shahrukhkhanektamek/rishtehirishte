<!--  Start Header Area -->
<?php echo view("web/include/header.php"); ?>
<!-- End Header Area -->

    <div class="hom-top inner_style">

    <?php echo view("web/include/header-nav.php"); ?>

    <!-- BANNER -->
    <section>
        <div class="str">
            <div class="ban-inn ab-ban pg-cont" style="background: linear-gradient(to right, rgb(137, 33, 107), rgb(218, 68, 83));">
                <div class="container">
                    <div class="row">
                        <div class="hom-ban">
                            <div class="ban-tit">
                                <h1>Complete Your Profile</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

   



    <!-- ABOUT START -->
    <section class="pt-60 pb-60">
        <div class="ab-wel">
            <div class="container">
                <div class="row justify-content-between mt-5">
                    <div class="col-md-3">
                        <div class="stepwizard">
                            <div class="stepwizard-row setup-panel">
                                <div class="stepwizard-step">
                                    <a type="button" class="btn-step btn-circle">1</a>
                                    <p><span>Step 1</span> Profile Detail</p>
                                </div>
                                <div class="stepwizard-step">
                                    <a type="button" class="btn-default btn-circle" disabled="disabled">2</a>
                                    <p><span>Step 2</span> Education & Profession</p>
                                </div>
                                <div class="stepwizard-step">
                                    <a type="button" class="btn-default btn-circle" disabled="disabled">3</a>
                                    <p><span>Step 3</span> Lifestyle & Family</p>
                                </div>
                                <div class="stepwizard-step">
                                    <a type="button" class="btn-default btn-circle" disabled="disabled">4</a>
                                    <p><span>Step 4</span> Requirement for partner</p>
                                </div>
                                <div class="stepwizard-step d-none">
                                    <a type="button" class="btn-default btn-circle" disabled="disabled">5</a>
                                    <p><span>Step 5</span> Basic Detail</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8">

                        <div class="row setup-content" id="step-1">
                            <?php echo view("user/profile/steps/step2") ?>
                        </div>
                        <div class="row setup-content d-none" id="step-2" >
                            <?php echo view("user/profile/steps/step3") ?>
                        </div>
                        <div class="row setup-content d-none" id="step-3" >
                            <?php echo view("user/profile/steps/step4") ?>
                        </div>
                        <div class="row setup-content d-none" id="step-4" >
                            <?php echo view("user/profile/steps/step5") ?>
                        </div>
                        <div class="row setup-content d-none" id="step-5">
                            <?php echo view("user/profile/steps/step1") ?>        
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END -->

<!--  Start Footer Area -->
<?php echo view("web/include/footer.php"); ?>

<script>
   var maritalstatusstep2 = $('select[name="maritalstatus"]');
var havechildrenstep2 = $('select[name="havechildren"]');

$(document).on("change", maritalstatusstep2, function(e) {
    setHideShowFliedsstep2();
});

function setHideShowFliedsstep2() {
    if (maritalstatusstep2.val() === 'Never Married') {
        havechildrenstep2.parent().hide();
    } else {
        havechildrenstep2.parent().show();            
    }
}
setHideShowFliedsstep2();
</script>



<script>
    var maritalstatusR = $('select[name="maritalstatusR[]"]');
    var havechildrenR = $('select[name="childrenR"]');

    $(document).on("change", maritalstatusR ,(function(e) {
        setHideShowFliedsR();
    }));

    function setHideShowFliedsR() {
        if($(maritalstatusR).val().includes('Never Married'))
        {
            $(havechildrenR).parent().hide();
        }
        else
        {
            $(havechildrenR).parent().show();            
        }
    }
    setHideShowFliedsR();
</script>

<!-- End Footer Area --> 