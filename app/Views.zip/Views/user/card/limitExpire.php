<div class="row">

    <div class="col-12 text-center">

        <?php if($type2==1){ ?>
            <h2 >You have reached the Daily Limit to Send interest to Members</h2>
        <?php } ?>

        <?php if($type2==2){ ?>
            <h2 >You have reached the Daily Limit for View Profile</h2>            
        <?php } ?>
        
    </div>
</div>